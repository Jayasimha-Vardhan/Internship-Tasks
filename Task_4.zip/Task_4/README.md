# Python Task 04 – HackerRank Coding Practice

This folder contains separate solutions for Q1–Q20 from the task PDF.

## Files
- `problem1.py` through `problem20.py`: individual HackerRank solutions.
- Each file starts with the problem name and its HackerRank URL, as required by the task instructions.

## Notes
- Submit each solution on HackerRank and confirm it passes before treating it as accepted.
- Upload this `Task_4` folder under `Python_Tasks/Task_4/` in your public `Internship_Tasks` GitHub repository.
- For LMS, submit only `Task_4.zip`.

Solutions are prepared to match the standard HackerRank problem input/output formats.
