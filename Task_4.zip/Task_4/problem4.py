# Q4: Loops
# HackerRank: https://www.hackerrank.com/challenges/python-loops/problem

n = int(input())

for i in range(n):
    print(i * i)
