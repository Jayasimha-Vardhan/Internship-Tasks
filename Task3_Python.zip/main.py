# Task 3: Test all 15 functions from solutions.py
from solutions import (
    word_frequency,
    character_frequency,
    first_non_repeating_character,
    are_anagrams,
    first_repeating_character,
    move_zeros_to_end,
    second_highest_distinct,
    remove_duplicates_preserve_order,
    find_missing_number,
    find_first_pair,
    closest_to_zero,
    common_elements,
    rotate_right,
    max_consecutive_sum,
    all_unique_pairs,
)

# Q1: Given example + additional test
print("Q1:", word_frequency("python is easy and python is powerful"))
print("Q1 extra:", word_frequency("red blue red"))

# Q2
print("Q2:", character_frequency("banana"))
print("Q2 extra:", character_frequency("hello"))

# Q3
print("Q3:", first_non_repeating_character("swiss"))
print("Q3 extra:", first_non_repeating_character("aabb"))

# Q4
print("Q4:", are_anagrams("listen", "silent"))
print("Q4 extra:", are_anagrams("hello", "world"))

# Q5
print("Q5:", first_repeating_character("programming"))
print("Q5 extra:", first_repeating_character("abc"))

# Q6
print("Q6:", move_zeros_to_end([0, 3, 0, 1, 2, 0, 4]))
print("Q6 extra:", move_zeros_to_end([1, 0, 2]))

# Q7
print("Q7:", second_highest_distinct([10, 20, 40, 30, 40, 20]))
print("Q7 extra:", second_highest_distinct([5, 5]))

# Q8
print("Q8:", remove_duplicates_preserve_order([4, 2, 4, 5, 2, 7, 5]))
print("Q8 extra:", remove_duplicates_preserve_order([1, 1, 2, 3, 2]))

# Q9
print("Q9:", find_missing_number([1, 2, 4, 5, 6], 6))
print("Q9 extra:", find_missing_number([1, 3, 4], 4))

# Q10
print("Q10:", find_first_pair([2, 7, 11, 15], 9))
print("Q10 extra:", find_first_pair([1, 4, 2, 3], 5))

# Q11
print("Q11:", closest_to_zero([-8, -3, 2, 5, -2]))
print("Q11 extra:", closest_to_zero([-1, 1, 4]))

# Q12
print("Q12:", common_elements([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]))
print("Q12 extra:", common_elements([2, 2, 1, 3], [3, 2]))

# Q13
print("Q13:", rotate_right([1, 2, 3, 4, 5], 2))
print("Q13 extra:", rotate_right([1, 2, 3], 0))

# Q14
print("Q14:", max_consecutive_sum([4, 7, 2, 9, 5]))
print("Q14 extra:", max_consecutive_sum([-4, -2, -8]))

# Q15
print("Q15:", all_unique_pairs([2, 4, 3, 5, 7, 8, 1], 9))
print("Q15 extra:", all_unique_pairs([1, 1, 2, 2, 3, 4], 5))
