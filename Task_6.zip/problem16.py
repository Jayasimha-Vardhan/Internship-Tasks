# Problem 16: Check Subset
# HackerRank: https://www.hackerrank.com/challenges/py-check-subset/problem

tests = int(input())

for _ in range(tests):
    n = int(input())
    a = set(map(int, input().split()))

    m = int(input())
    b = set(map(int, input().split()))

    print(a.issubset(b))
