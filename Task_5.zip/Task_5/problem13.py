# Problem: Nested Lists
# HackerRank: https://www.hackerrank.com/challenges/nested-list/problem

records = []

for _ in range(int(input())):
    name = input()
    score = float(input())
    records.append([name, score])

scores = sorted(set(score for name, score in records))
second_lowest = scores[1]

for name in sorted(name for name, score in records if score == second_lowest):
    print(name)
