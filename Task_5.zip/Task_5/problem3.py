# Problem: Mutations
# HackerRank: https://www.hackerrank.com/challenges/python-mutations/problem

s = input()
i, c = input().split()
i = int(i)

print(s[:i] + c + s[i + 1:])
