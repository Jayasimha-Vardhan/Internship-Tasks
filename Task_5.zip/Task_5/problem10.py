# Problem: Swap Case
# HackerRank: https://www.hackerrank.com/challenges/swap-case/problem

def swap_case(s):
    return s.swapcase()

if __name__ == "__main__":
    s = input()
    print(swap_case(s))
