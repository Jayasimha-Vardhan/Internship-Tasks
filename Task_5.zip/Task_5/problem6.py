# Problem: Introduction to Sets
# HackerRank: https://www.hackerrank.com/challenges/py-introduction-to-sets/problem

def average(array):
    heights = set(array)
    return sum(heights) / len(heights)

if __name__ == "__main__":
    n = int(input())
    arr = list(map(int, input().split()))
    print(average(arr))
